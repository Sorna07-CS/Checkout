curl --location --request GET 'https://api.checkout.com/broadcast/events?payment_id=pay_ok2ynq6ubn3ufmo6jsdfmdvy5q'
  --header 'Authorization: secret_key_broadcast'