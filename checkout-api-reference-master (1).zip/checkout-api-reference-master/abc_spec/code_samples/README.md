# Code samples

Generate [x-code-samples](https://github.com/Rebilly/ReDoc/blob/master/docs/redoc-vendor-extensions.md#x-code-samples)
Path `<lang>/<path>/<HTTP verb>.<extension>` where:

- `<lang>` - name of the language from [this](https://github.com/github/linguist/blob/master/lib/linguist/popular.yml) list.
- `<path>` - path of target method, where all slashes replaced with `@` sign.
- `<HTTP verb>` - verb of target method.
- `<extension>` - ignored.
