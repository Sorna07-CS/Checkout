# Definitions

- Write each definition in separate file
- File name repeat the resource name, i.e. `Customer.yaml`
