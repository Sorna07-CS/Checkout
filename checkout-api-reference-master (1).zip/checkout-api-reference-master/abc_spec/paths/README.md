# Paths

- Write each path specification in separate file
- File name repeat the path, the slash replaced with `@` sign, i.e. `user@{username}.yaml` matches to `user/{username}`
